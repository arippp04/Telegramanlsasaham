# Telegram token dan user ID
TELEGRAM_TOKEN = 'your_token_here'
TELEGRAM_USER_ID = 123456789
