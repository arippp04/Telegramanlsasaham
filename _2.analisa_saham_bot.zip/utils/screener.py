# Modul screener teknikal dan fundamental saham
